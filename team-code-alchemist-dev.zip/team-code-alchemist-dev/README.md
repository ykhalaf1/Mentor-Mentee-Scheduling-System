# Mentorship-App-2

## Summary

This project is a web app that connects mentors to mentees in a 1:1 fashion to provide a seamless experience for mentees to gain professional advising on the Ummah Professionals website. Our apporach is to reduce the time it takes for mentors and mentees to be paired by adding automated features that admins can utilize to better monitor the web page.

## Tech Stack

Web development: React, Node, Express.Js
Databases: Firestore
Editor: Visual Studio

## Features

Mentee application form
Mentor application form
Calendar and shedular
Admin portal
User portal for mentees and mentors

## Team

Omar: Project manager

Amina: UI/UX Designer

Ryan: Backend developer

Maruf: Backend developer

Noor: Frontend developer

Yassir: Frontend developer
